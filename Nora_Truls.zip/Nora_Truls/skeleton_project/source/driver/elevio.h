/**
 * @file
 * @brief Headerfil for å hente input og sette output til heissystemet. NEIOVEL
 * @author Lil Cucumber n el illegal flame!
 */

#pragma once

#define N_FLOORS 4
/**
 * @brief enum type for motorretning.
 * 
 */
typedef enum { 
    DIRN_DOWN   = -1,
    DIRN_STOP   = 0,
    DIRN_UP     = 1
} MotorDirection;


#define N_BUTTONS 3

/**
 * @brief knapp for heis i entre
 * 
 */
typedef enum { 
    BUTTON_HALL_UP      = 0,
    BUTTON_HALL_DOWN    = 1,
    BUTTON_CAB          = 2
} ButtonType;

/**
 * @brief Starter opp vertikal menneskeforflytningsenhet
 * 
 */
void elevio_init(void);

/**
 * @brief setter heiint floor = elevio_floorSensor(); etasjeknappene inni heisen. (også opp ned?)
 * @param[in] floor hvikjen etasje current?
 * @param[in] button 
 * @param[in] value
 */
void elevio_buttonLamp(int floor, ButtonType button, int value);
void elevio_floorIndicator(int floor);
void elevio_doorOpenLamp(int value);
/**
 * @brief Setter stopplampen av/på.
 * 
 * @param[in] value. 0/1.
 */
void elevio_stopLamp(int value);

/**
 * @brief Sjekker om spesifisert knapp er trykket inn.
 * 
 * @param[in] floor 
 * @param[in] button 
 * @return int 
 */
int elevio_callButton(int floor, ButtonType button);

/**
 * @brief Returnerer -1 med mindre heisen utløser en sensor. Da returner den (0, 3) 
 * @return int 
 */
int elevio_floorSensor(void);
/**
 * @brief Ser om stoppknappen er aktiv eller ikke.
 * 
 * @return int. 1=aktiv, 0=ikke aktiv.
 */
int elevio_stopButton(void);
/**
 * @brief Henter info om obstruksjonknappen er aktiv eller ikke.
 * 
 * @return int. 1=aktiv, 0=ikke aktiv. 
 */
int elevio_obstruction(void);

