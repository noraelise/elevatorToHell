#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include "driver/elevio.h"
#include "elevatorInit.h"
#include "states.h"

int main()
{
    elevio_init();

    printf("=== Example Program ===\n");
    printf("Press the stop button on the elevator panel to exit\n");

    int strtFloor = goToDefinedState();
    printf("%d  ", strtFloor);

    Button floorPanel[4][2];
    Button *floorPanelPtr = NULL;

    floorPanelPtr = &floorPanel[0][0];

    for (int i = 0; i < N_FLOORS; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            struct button btn = {j, i, 0};
            floorPanel[i][j] = btn;
            printf("fillin up");
        }
    }

    while (1)
    {
        /*int floor = elevio_floorSensor();
        elevio_buttonLamp(0, BUTTON_CAB, 0);
        elevio_buttonLamp(2, BUTTON_CAB, 0);
        elevio_buttonLamp(1, BUTTON_HALL_UP, 1);
        int sjekk = elevio_callButton(3, BUTTON_HALL_DOWN);
        printf("\n%d", sjekk);
        if (floor >= 0)
        {
            elevio_floorIndicator(elevio_floorSensor());
        }

        if (floor == N_FLOORS - 1)
        {
            elevio_motorDirection(DIRN_DOWN);
            motor = DIRN_DOWN;
            elevio_doorOpenLamp(1);
            sleep(3);
            elevio_doorOpenLamp(0);
        }
        if (floor == 0)
        {
            elevio_motorDirection(DIRN_UP);
        }*/
        if (elevio_stopButton())
        {
            elevio_motorDirection(DIRN_STOP);
            elevio_doorOpenLamp(0);
            break;
        }
    }
    /*
        while (1)
        {
            int floor = elevio_floorSensor();
            printf("floor: %d \n", floor);

            if (floor == 0)
            {
                elevio_motorDirection(DIRN_UP);
                motor = DIRN_UP;
            }

            if (floor == N_FLOORS - 1)
            {
                elevio_motorDirection(DIRN_DOWN);
                motor = DIRN_DOWN;
            }

            for (int f = 0; f < N_FLOORS; f++)
            {
                for (int b = 0; b < N_BUTTONS; b++)
                {
                    int btnPressed = elevio_callButton(f, b);
                    elevio_buttonLamp(f, b, btnPressed);
                    // printf("\nKnapptrukk: %d", btnPressed); //the bitchs
                }
            }

            if (elevio_obstruction())
            {
                elevio_motorDirection(DIRN_STOP);

                printf("\nHvasssup");
                // elevio_stopLamp(1);
            }
            else
            {
                // elevio_motorDirection(DIRN_DOWN);
                printf("\nFloorsensor:%d", elevio_floorSensor());
                elevio_stopLamp(0);
                // printf("\nRead flåår: %d", floor);
                elevio_motorDirection(motor);
            }

            if (elevio_stopButton())
            {
                elevio_motorDirection(DIRN_STOP);

                break;
            }

            nanosleep(&(struct timespec){0, 20 * 1000 * 1000}, NULL);
        }
    */

    return 0;
}
