#pragma once
#include "states.h"

int goToDefinedState();
void turnOffLights();
void checkButton(Button floorPanelArray[heightOFSkyscraper][number of possibil]);
//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