#include "elevatorInit.h"
#include <stdio.h>
#include "driver/elevio.h"
#include "stdbool.h"
#include "driver/con_load.h"

int goToDefinedState(){
    turnOffLights();
    int floor = -1;
    while(floor!=0){
        floor = elevio_floorSensor();
        elevio_motorDirection(DIRN_DOWN);
        if (elevio_stopButton())
        {
            elevio_motorDirection(DIRN_STOP);
            elevio_doorOpenLamp(0);
            break;
        }
    }
    elevio_motorDirection(DIRN_STOP);
    elevio_floorIndicator(floor); //om floor <0, fiel
    return floor;
}

void turnOffLights(){
    for (int i = 0; i < N_FLOORS-1; i++)
    {
        elevio_buttonLamp(i, BUTTON_CAB, 0);
        elevio_buttonLamp(i, BUTTON_HALL_DOWN, 0); //finnes ingen down på floor 0
        elevio_buttonLamp(i, BUTTON_HALL_UP, 0);
    }
    
}

void checkButton(){

}