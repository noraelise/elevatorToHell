#pragma once
#include "driver/elevio.h"
#include <stdbool.h>

typedef struct button
{
    ButtonType btnType;
    int floor;
    int light;
} Button;

struct elevatorState
{
    int floor;
    MotorDirection direction;
};

struct elevatorPanel
{
    bool obstruction;
    bool stopBtn;
    bool door;
};
